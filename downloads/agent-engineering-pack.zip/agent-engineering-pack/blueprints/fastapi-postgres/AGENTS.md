# FastAPI + PostgreSQL Service Guide

## Commands
- Single test module: `uv run pytest tests/api/test_orders.py -q`
- Full suite against test DB: `uv run pytest`
- Lint & types: `uv run ruff check . && uv run mypy app`
- Create migration: `uv run alembic revision --autogenerate -m "<summary>"` (always inspect generated SQL before committing!)

## Service Invariants
- **Transactions:** Route handlers must not call `session.commit()` mid-request across multiple repositories; commit once at the unit-of-work boundary.
- **Concurrency:** Any balance, inventory, or state-transition update must use `SELECT ... FOR UPDATE` or an atomic conditional `UPDATE ... WHERE status = expected` checking `rowcount == 1`.
- **Schemas:** Separate SQLAlchemy ORM models (`app/models/`) from Pydantic wire schemas (`app/schemas/`). Never return ORM instances directly without an explicit `response_model`.
- **Migrations:** Never edit an already-merged Alembic revision in `alembic/versions/`. Ensure new non-nullable columns on populated tables follow expand-backfill-contract rather than table-locking defaults.
