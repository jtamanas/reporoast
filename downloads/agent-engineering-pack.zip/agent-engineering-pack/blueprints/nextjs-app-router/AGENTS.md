# Next.js App Router Engineering Guide

## Verification Commands
- Typecheck: `pnpm tsc --noEmit`
- Unit / integration tests: `pnpm vitest run <file>`
- E2E Playwright (targeted): `pnpm playwright test <spec>`
- Production build check (catches RSC boundary & dynamic-rendering errors): `pnpm build`

## Server vs Client Component Rules
- Default every component in `app/` and `components/` to a **React Server Component**. Add `'use client'` only at the narrowest interactive leaf that requires browser state, event listeners, or refs.
- Never import `server-only` modules, database clients, or environment secrets from any file reachable by a `'use client'` module.
- Perform mutations in `app/**/actions.ts` (`'use server'`). Re-authenticate the caller and validate form/JSON arguments with Zod inside **every** Server Action — treat Server Actions as public HTTP POST endpoints.

## Data Fetching & Caching
- Colocate reads in Server Components or `lib/queries/` helpers wrapped with React `cache()` for per-request deduplication.
- After writes, invalidate affected routes or cache tags explicitly (`revalidatePath` / `revalidateTag`) rather than forcing client router reloads.

## Guardrails
- Do not modify existing committed Prisma/Drizzle SQL migration files; generate a new migration instead.
- Respect `prefers-reduced-motion` and verify keyboard focus rings on all custom interactive controls.
