# Agent-Ergonomic CLI Design Guide

## Core Principles for CLIs Driven by AI & Automation
1. **Non-interactive by default when non-TTY:** Never hang waiting for stdin prompts when `!process.stdin.isTTY` or `--yes` / `--json` is passed; fail fast with an actionable flag hint instead.
2. **Structured output (`--json`):** Every read and mutation command supports `--json`, writing valid JSON to `stdout` and all logs/progress spinners strictly to `stderr`.
3. **Distinct exit codes:**
   - `0` — Success
   - `2` — Usage / invalid flag or schema error
   - `3` — Resource not found
   - `4` — Auth / permission failure
   - `1` — Unexpected runtime error
4. **Safe previews (`--dry-run`):** Destructive or external-side-effect commands support `--dry-run`, returning the planned diff/payload without mutating remote state.
