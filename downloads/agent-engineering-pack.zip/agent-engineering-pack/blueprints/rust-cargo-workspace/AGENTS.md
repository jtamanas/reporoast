# Rust Cargo Workspace Guide

## Commands
- Fast compile check: `cargo check --workspace --all-targets`
- Single test: `cargo test -p <crate_name> <test_filter> -- --nocapture`
- Lint (deny warnings): `cargo clippy --workspace --all-targets -- -D warnings`
- Format check: `cargo fmt --all -- --check`

## Engineering Rules
- `unwrap()` and `expect()` are forbidden in library and server request paths (`crates/*/src/`). Use `?` with `thiserror` domain enums in library crates and `anyhow::Context` at binary entrypoints.
- Keep `unsafe` blocks at zero unless profiling proves necessity; any `unsafe` block requires a `// SAFETY:` comment stating the exact invariant upheld.
- Do not hold `tokio::sync::Mutex` or `std::sync::Mutex` guards across `.await` points.
- Prefer borrowing (`&str`, `&[T]`) at public API inputs and owned types only when ownership transfers into state or async tasks.
