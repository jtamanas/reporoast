# Go Service Engineering Guide

## Commands
- Focused package test with race detector: `go test -race -run TestName ./internal/pkg/...`
- Full test suite: `go test -race ./...`
- Vet & static checks: `go vet ./... && staticcheck ./...`

## Go Idioms & Guardrails
- Thread `context.Context` as the first parameter across all I/O, RPC, and DB boundaries; never store `context.Context` on a struct.
- Wrap returned errors with caller context (`fmt.Errorf("load invoice %s: %w", id, err)`) so `errors.Is` and `errors.As` keep working upstream.
- Always bound goroutine lifetimes: every spawned goroutine must have a deterministic shutdown path (`errgroup.WithContext` or channel cancellation) and zero unbuffered channel leak paths on early error return.
- Close `http.Response.Body` (`defer resp.Body.Close()`) only after checking `err == nil`, and drain/limit body reads with `io.LimitReader` on untrusted upstreams.
- Prefer table-driven tests (`t.Run`) against real interfaces/in-memory stores over reflection-heavy mock generators.
