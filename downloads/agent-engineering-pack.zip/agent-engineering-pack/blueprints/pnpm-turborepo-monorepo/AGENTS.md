# Monorepo Guide (`pnpm` + Turborepo)

## Commands
- Build dependencies + target package: `pnpm turbo run build --filter=<pkg>...`
- Run tests in changed packages only: `pnpm turbo run test --filter=...[origin/main]`
- Single package test file: `pnpm --filter <pkg> test <path/to/file.test.ts>`
- Typecheck workspace: `pnpm turbo run typecheck`

## Workspace Boundaries
- `packages/core` — Runtime-agnostic domain logic; zero React, Node-only, or browser-only globals.
- `packages/ui` — Design-system primitives; consumes design tokens, zero business API calls.
- `apps/*` — Deployable applications; apps may import from `packages/*` but **never** from another `apps/*` directory.
- Keep shared dependency versions aligned in `pnpm-workspace.yaml` catalog; never add duplicate React/TypeScript major versions inside leaf `package.json` files.
