# Repository Engineering Guide

## Commands (Run Before Finishing Any Task)
- Typecheck: `npm run typecheck` (`tsc --noEmit`)
- Single test file (preferred during iteration): `npx vitest run <path/to/file.test.ts>`
- Full test suite: `npm test`
- Lint & format check: `npm run lint`

## Architecture & Module Boundaries
- `src/domain/` — Pure business logic and value types. Zero network, filesystem, or database imports allowed here.
- `src/adapters/` — External I/O wrappers (HTTP clients, DB repositories, queues). Keep thin; validate untrusted payloads at the boundary with Zod.
- `src/app/` — Use-case orchestration wiring domain logic to adapters.
- `src/cli/` or `src/http/` — Transport layer only (status codes, argument parsing, serialization).

## Coding Invariants
- Never use `any` or `as unknown as T` to silence compiler errors; narrow unknown inputs explicitly.
- Propagate `AbortSignal` into outbound `fetch` and long-running async operations.
- Prefer returning typed result unions (`{ ok: true; value: T } | { ok: false; error: E }`) for expected domain failures; throw only on programmer bugs or unrecoverable infrastructure faults.
- Do not edit generated files under `src/generated/` directly; regenerate via `npm run codegen`.

## Testing Standards
- Test observable behavior through public module exports rather than mocking internal helpers.
- Every bug fix must start with a failing regression test that reproduces the defect before applying the fix.
