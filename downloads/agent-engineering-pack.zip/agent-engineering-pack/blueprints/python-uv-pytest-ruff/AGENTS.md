# Python Engineering Guide (`uv` + `pytest` + `ruff`)

## Commands
- Run single test (fast loop): `uv run pytest tests/path/to/test_module.py -q`
- Run single test case: `uv run pytest tests/path/to/test_module.py -k "test_name" -vv`
- Typecheck: `uv run ty check` (or `uv run mypy src`)
- Lint & format check: `uv run ruff check . && uv run ruff format --check .`
- Add dependency: `uv add <pkg>` (never edit `uv.lock` manually or run bare `pip install`).

## Code Structure & Conventions
- Source lives in `src/<package_name>/` (`src` layout) so tests always run against the installed package rather than implicit working-directory imports.
- Annotate all public function signatures and dataclasses/Pydantic models with explicit types (`from __future__ import annotations`).
- Always pass explicit `timeout=` on outbound `httpx`/`requests`/`urllib` calls and `encoding="utf-8"` on `Path.read_text` / `Path.write_text`.
- Catch specific exception classes (`httpx.TimeoutException`, `ValueError`), never bare `except:` or silent `except Exception: pass`.

## Testing Rules
- Use `tmp_path` and `monkeypatch` fixtures instead of mutating global process state or writing inside the repo tree.
- Avoid mocking internal functions within the unit under test; use in-memory fakes or `httpx.MockTransport` at the I/O boundary.
