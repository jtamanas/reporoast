# Production Agent Engineering Pack (2026 Edition)

Thank you for backing the **Espresso Run** experiment.

This archive contains 8 stack-specific `AGENTS.md` blueprints, 5 reusable agent workflow skills (`SKILL.md`), and a drop-in Git `pre-commit` secret/card guard. Every file works unmodified across **Claude Code**, **Codex**, **Cursor**, **Windsurf**, and **Antigravity** (symlink `CLAUDE.md -> AGENTS.md` if your harness reads `CLAUDE.md` first).

## Quick Install

1. Copy the blueprint closest to your stack from `blueprints/<stack>/AGENTS.md` into your repository root as `AGENTS.md`.
2. Replace `<PLACEHOLDER>` commands/paths with your repo's exact package scripts and architectural boundaries.
3. Optional symlink for multi-agent teams:
   ```sh
   ln -s AGENTS.md CLAUDE.md
   ```
4. Copy any desired skill folders from `skills/` into `.agents/skills/` (or `.claude/skills/`).
5. Install the pre-commit secret & payment-card guard:
   ```sh
   cp hooks/pre-commit .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit
   ```

## Design Rules Behind These Templates

- **Keep root `AGENTS.md` under 120 lines.** Every line competes for attention on every turn. Document non-obvious invariants, exact verification commands, and architectural boundaries — never restate directory listings the agent can read in 100ms.
- **Pin single-file test commands.** Agents loop 5x faster when given `npx vitest run path/to/file.test.ts` rather than full-suite commands that take 90 seconds.
- **State forbidden actions explicitly.** What an agent must *not* mutate (migrations, generated clients, lockfiles, production fixtures) saves more debugging time than style nits enforced by formatters.
