---
name: deep-module-refactor
description: Identify shallow pass-through wrappers, leaky abstractions, and temporal coupling in a codebase and consolidate them into deep, easily-tested modules.
---

# Deep Module Architecture Audit

Evaluate candidate modules using John Ousterhout's interface-vs-implementation ratio:

- **Deep module (goal):** Small, obvious public interface hiding substantial domain complexity (validation, retries, caching, edge cases).
- **Shallow module (smell):** Wide surface area or multi-file pass-through chains where changing one field requires touching 6 files in lockstep.

## Refactor Checklist
1. Find co-change clusters (`git log --stat`) where 3+ files always change together for one concept.
2. Check if callers must call methods in a secret temporal order (`init()` before `load()` before `validate()`); replace with a single constructor/factory returning an already-valid value.
3. Pull format/transport details out of core logic so 90% of edge cases can be tested in milliseconds without booting servers or mocking 8 dependencies.
