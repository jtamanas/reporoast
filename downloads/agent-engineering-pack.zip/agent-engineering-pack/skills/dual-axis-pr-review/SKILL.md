---
name: dual-axis-pr-review
description: Audit a git branch or commit range across two independent axes: Spec Compliance (did we build every requirement and edge case?) and Engineering Standards (bugs, security, concurrency, architecture).
---

# Dual-Axis Diff Review

Inspect `git diff <base>...HEAD` across two distinct checklists before merging or opening a PR:

## Axis 1: Spec & Edge-Case Completeness
- Does every acceptance criterion in the issue/brief map to an exercised code path and test?
- What happens on empty input, partial upstream failure, duplicate retry, timeout, or concurrent execution?
- Are backward compatibility and migration order preserved for existing callers?

## Axis 2: Correctness, Security & Architecture
- **Injection & Trust Boundaries:** Are all user/webhook/LLM inputs validated and parameterized before SQL, shell, path, or HTML rendering?
- **Resource & Concurrency Safety:** Are timeouts set, handles closed, locks bounded, and partial writes rolled back cleanly?
- **Information Leakage:** Could error responses, logs, or commits expose tokens, PII, or payment card numbers?

Report findings ordered by severity (`P0 Blocker`, `P1 Bug/Security`, `P2 Maintainability`), citing exact `file:line` locations and a concrete fix for each.
