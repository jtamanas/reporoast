---
name: red-green-tdd
description: Strict Red-Green-Refactor test-driven development loop focused on public module behavior rather than internal mocks.
---

# Red-Green-Refactor Workflow

1. **Red:** Write one focused test targeting the public behavior or edge case you are adding. Run it immediately and confirm it fails for the expected reason (missing behavior, not a syntax/import typo).
2. **Green:** Write the simplest implementation that makes the new test and all existing tests pass without premature generalization.
3. **Refactor:** Eliminate duplication, sharpen names, and extract deep helper modules while keeping the test suite green at every step.

## Anti-Patterns to Avoid
- Mocking internal collaborators inside the same module (couples tests to implementation rather than behavior).
- Asserting exact log strings or private field values when a return value or state transition can be asserted instead.
- Batching 10 untested files before running the test runner for the first time.
