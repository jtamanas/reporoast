---
name: root-cause-diagnose
description: Disciplined bug and regression diagnosis loop (reproduce -> minimize -> hypothesize -> instrument -> fix -> regression-test). Use whenever debugging a failing test, production error, race condition, or performance regression.
---

# Root-Cause Diagnosis Loop

Never guess-and-patch before reproducing or proving the root cause. Follow these six steps in order:

1. **Reproduce deterministically.** Capture the exact command, input, stack trace, or timing measurement that demonstrates the failure.
2. **Minimize the reproducer.** Strip unrelated setup until you have the smallest input or unit test that still fails 100% of the time.
3. **List 2-3 competing hypotheses.** Write down what state or control-flow assumption must be false for this symptom to occur, and identify the single observation that falsifies each hypothesis.
4. **Instrument narrowly.** Read code paths and add targeted assertions/logs at the boundary between known-good and first-corrupted state. Remove temporary logs once confirmed.
5. **Fix the invariant, not the symptom.** Repair the underlying contract violation rather than adding defensive `if (!x) return` guards downstream that mask corrupt state.
6. **Lock in with a regression test.** Verify the new test fails with your fix reverted and passes with your fix applied.
