---
name: agent-ergonomic-cli
description: Design or retrofit command-line tools so AI agents and CI pipelines can drive them deterministically with zero hung prompts or brittle text scraping.
---

# Agent-Ergonomic CLI Checklist

- **Never block on interactive prompts in non-TTY contexts.** Detect `!isatty(0)` and return exit code `2` naming the missing `--flag`.
- **Support `--json` everywhere.** Emit one parseable JSON document on `stdout`; route warnings, progress bars, and debug traces to `stderr`.
- **Keep `--help` self-sufficient.** Include one concrete invocation example per subcommand and document allowed enum values inline.
- **Make retries safe.** Support idempotency keys or `--if-not-exists` semantics so an agent retrying after a timeout does not create duplicate resources.
